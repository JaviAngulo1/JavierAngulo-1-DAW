
package Excepciones;

public class SudokuExcepcion extends Exception {
    public SudokuExcepcion(String mensaje) {
        super(mensaje);
    }
}

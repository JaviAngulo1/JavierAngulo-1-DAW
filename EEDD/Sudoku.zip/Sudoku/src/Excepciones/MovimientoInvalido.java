// MovimientoInvalidoException.java
package Excepciones;

public class MovimientoInvalido extends Excepciones.SudokuExcepcion {
    public MovimientoInvalido(String mensaje) {
        super(mensaje);
    }
}
